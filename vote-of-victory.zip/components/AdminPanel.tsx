import React, { useState } from 'react';
import { Contestant } from '../types';
import ResultsScreen from './ResultsScreen';

interface AdminPanelProps {
  contestants: Contestant[];
  onAddContestant: (name: string, image: string) => void;
  onDeleteContestant: (id: number) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ contestants, onAddContestant, onDeleteContestant }) => {
  const [newName, setNewName] = useState('');
  const [newImage, setNewImage] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [fileName, setFileName] = useState('');

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit
          setError('Image is too large. Please select a file smaller than 2MB.');
          return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewImage(reader.result as string);
        setFileName(file.name);
        setError('');
      };
      reader.onerror = () => {
        setError('Failed to read the image file.');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newImage) {
      setError('Please provide a name and an image.');
      return;
    }
    if (contestants.length >= 15) {
      setError('You can have a maximum of 15 nominees.');
      return;
    }
    onAddContestant(newName, newImage);
    setNewName('');
    setNewImage(null);
    setFileName('');
    setError('');
  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this nominee? This action cannot be undone.')) {
        onDeleteContestant(id);
    }
  }

  return (
    <div className="w-full flex flex-col gap-8">
      {/* Add Nominee Section */}
      <div className="p-6 bg-white/10 backdrop-blur-md rounded-2xl shadow-xl border border-white/20">
        <h2 className="text-3xl font-bold mb-4 font-comic text-brand-yellow">Admin Panel</h2>
        <form onSubmit={handleAdd} className="flex flex-col md:flex-row gap-4 items-center">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Nominee Name"
            className="p-3 bg-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink w-full md:w-auto flex-grow"
          />
          <label className="w-full md:w-auto px-4 py-3 bg-brand-blue text-white font-semibold rounded-lg shadow-md cursor-pointer hover:bg-brand-blue/80 transition-colors text-center">
            <span>{fileName || 'Upload Image'}</span>
            <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
          </label>
          <button type="submit" className="w-full md:w-auto px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 font-bold rounded-lg shadow-lg hover:scale-105 transform transition-transform">
            Add Nominee
          </button>
        </form>
        {error && <p className="mt-4 text-red-400 font-semibold">{error}</p>}
      </div>

      {/* Manage Nominees Section */}
      <div className="p-6 bg-white/10 backdrop-blur-md rounded-2xl shadow-xl border border-white/20">
        <h3 className="text-2xl font-bold mb-4 font-comic text-brand-yellow">Manage Nominees ({contestants.length}/15)</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {contestants.map(c => (
            <div key={c.id} className="relative flex flex-col items-center text-center p-2 bg-black/20 rounded-lg">
              <img src={c.image} alt={c.name} className="w-24 h-24 rounded-full border-2 border-brand-yellow mb-2"/>
              <p className="font-semibold text-sm break-all">{c.name}</p>
              <button onClick={() => handleDelete(c.id)} className="absolute -top-2 -right-2 w-8 h-8 bg-red-600 text-white font-bold rounded-full flex items-center justify-center shadow-lg hover:bg-red-700 transition-colors text-xl">
                &times;
              </button>
            </div>
          ))}
          {contestants.length === 0 && <p className="col-span-full text-center py-4">No nominees yet. Add one above!</p>}
        </div>
      </div>
      
      {/* Results Section */}
      <ResultsScreen contestants={contestants} onBack={() => {}} isFinalResults />
    </div>
  );
};

export default AdminPanel;
