import React, { useState } from 'react';
import { CORRECT_LOGIN_CODE, ADMIN_LOGIN_CODE } from '../constants';

interface LoginScreenProps {
  onLoginSuccess: (role: 'user' | 'admin') => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (code === CORRECT_LOGIN_CODE) {
      setError('');
      onLoginSuccess('user');
    } else if (code === ADMIN_LOGIN_CODE) {
      setError('');
      onLoginSuccess('admin');
    }
    else {
      setError('Oops! Wrong code. Please try again.');
      setCode('');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center text-center p-6 bg-white/10 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 animate-pop-in">
      <h2 className="text-5xl mb-4 font-comic text-brand-yellow" style={{textShadow: '2px 2px 0 #000'}}>Welcome!</h2>
      <p className="mb-6 text-lg">Enter the secret code to continue.</p>
      <form onSubmit={handleLogin} className="flex flex-col items-center gap-4">
        <input
          type="password"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="••••••"
          className="p-3 text-center text-3xl font-bold tracking-[1em] bg-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-4 focus:ring-brand-pink transition-all duration-300 w-64"
          maxLength={6}
          autoFocus
        />
        <button
          type="submit"
          className="px-8 py-3 bg-gradient-to-r from-brand-pink to-orange-400 text-white font-bold text-xl rounded-full shadow-lg hover:scale-105 transform transition-transform duration-300 focus:outline-none focus:ring-4 focus:ring-brand-yellow"
        >
          Enter
        </button>
      </form>
      {error && <p className="mt-4 text-brand-yellow font-semibold animate-bounce">{error}</p>}
    </div>
  );
};

export default LoginScreen;
