
import React from 'react';
import ResultsScreen from './ResultsScreen';
import { Contestant } from '../types';

interface VotingClosedScreenProps {
  results: Contestant[];
}

const VotingClosedScreen: React.FC<VotingClosedScreenProps> = ({ results }) => {
  return (
    <div className="flex flex-col items-center text-center">
      <div className="p-6 bg-white/10 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 mb-8">
        <h2 className="text-5xl font-display text-brand-yellow animate-bounce-slow">Voting Is Closed!</h2>
        <p className="mt-2 text-xl font-semibold">
          Thanks for participating this week. Voting will reopen on Sunday with new nominees!
        </p>
      </div>
      
      <div className="w-full max-w-4xl">
        <ResultsScreen contestants={results} onBack={() => {}} isFinalResults={true} />
      </div>
    </div>
  );
};

export default VotingClosedScreen;
