import React, { useState, useEffect, useCallback } from 'react';
import { Contestant } from '../types';
import { DAILY_VOTE_LIMIT } from '../constants';
import ResultsScreen from './ResultsScreen';

const ContestantCard: React.FC<{ contestant: Contestant; onVote: (id: number) => void; canVote: boolean }> = ({ contestant, onVote, canVote }) => {
  const [isVoted, setIsVoted] = useState(false);

  const handleVoteClick = () => {
    if(!canVote) return;
    onVote(contestant.id);
    setIsVoted(true);
    setTimeout(() => setIsVoted(false), 500); // Reset animation state
  };

  return (
    <div 
      className={`relative flex flex-col items-center text-center p-4 bg-white/10 backdrop-blur-md rounded-2xl shadow-lg border border-white/20 transition-transform duration-300 ${canVote ? 'cursor-pointer hover:scale-105' : 'cursor-not-allowed'}`}
      onClick={handleVoteClick}
    >
      <div className="relative">
        <img src={contestant.image} alt={contestant.name} className="w-32 h-32 rounded-full border-4 border-brand-yellow shadow-lg mb-4" />
        {isVoted && (
           <div className="absolute inset-0 flex items-center justify-center text-5xl font-bold text-white bg-black/50 rounded-full animate-pop-in" style={{textShadow: '2px 2px 4px #000'}}>+1</div>
        )}
      </div>
      <h3 className="text-2xl font-bold font-display">{contestant.name}</h3>
      <p className="text-xl font-semibold text-brand-yellow">{contestant.votes} Votes</p>
      {!canVote && <p className="text-xs mt-2 text-red-400">No votes left!</p>}
    </div>
  );
};

interface VotingScreenProps {
    contestants: Contestant[];
    onVotesChange: (updatedContestants: Contestant[]) => void;
}

const VotingScreen: React.FC<VotingScreenProps> = ({ contestants, onVotesChange }) => {
  const [userVotesToday, setUserVotesToday] = useState<number>(0);
  const [showResults, setShowResults] = useState<boolean>(false);
  const [isLoadingResults, setIsLoadingResults] = useState<boolean>(false);
  const remainingVotes = DAILY_VOTE_LIMIT - userVotesToday;

  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    const lastVoteDate = localStorage.getItem('lastVoteDate');

    if (lastVoteDate !== today) {
      localStorage.setItem('userVotesToday', '0');
      localStorage.setItem('lastVoteDate', today);
      setUserVotesToday(0);
    } else {
      setUserVotesToday(Number(localStorage.getItem('userVotesToday') || '0'));
    }
  }, []);

  const handleVote = (id: number) => {
    if (remainingVotes <= 0) return;

    const newContestants = contestants.map(c => 
      c.id === id ? { ...c, votes: c.votes + 1 } : c
    );
    onVotesChange(newContestants); // Notify parent component

    const newVotesToday = userVotesToday + 1;
    setUserVotesToday(newVotesToday);
    localStorage.setItem('userVotesToday', String(newVotesToday));
  };

  const handleViewResults = () => {
    setIsLoadingResults(true);
    setTimeout(() => {
      setShowResults(true);
      setIsLoadingResults(false);
    }, 5000); // 5-second delay
  };
  
  if (showResults) {
    return <ResultsScreen contestants={contestants} onBack={() => setShowResults(false)} />;
  }

  return (
    <div className="flex flex-col items-center">
      <div className="w-full max-w-md bg-black/30 backdrop-blur-sm p-4 rounded-xl text-center mb-8 shadow-lg border border-white/20">
        <h2 className="text-4xl font-display text-brand-yellow">{remainingVotes}</h2>
        <p className="text-lg font-semibold">Votes Remaining Today</p>
        <div className="w-full bg-gray-700 rounded-full h-4 mt-2">
          <div className="bg-gradient-to-r from-brand-pink to-brand-yellow h-4 rounded-full transition-all duration-500" style={{ width: `${(remainingVotes / DAILY_VOTE_LIMIT) * 100}%` }}></div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 w-full">
        {contestants.map(c => (
          <ContestantCard key={c.id} contestant={c} onVote={handleVote} canVote={remainingVotes > 0} />
        ))}
      </div>
      
      {contestants.length === 0 && <p className="text-2xl my-10 font-bold text-center">No nominees have been added yet. Please ask the admin to add some!</p>}

      <div className="mt-10">
        <button
          onClick={handleViewResults}
          disabled={isLoadingResults}
          className="px-10 py-4 bg-gradient-to-r from-brand-yellow to-orange-400 text-black font-bold text-2xl rounded-full shadow-lg hover:scale-105 transform transition-transform duration-300 focus:outline-none focus:ring-4 focus:ring-brand-pink disabled:opacity-70 disabled:cursor-wait"
        >
          {isLoadingResults ? 'Calculating...' : 'View Results'}
        </button>
        {isLoadingResults && <p className="text-center mt-2 animate-pulse">Please wait, counting the votes!</p>}
      </div>
    </div>
  );
};

export default VotingScreen;
