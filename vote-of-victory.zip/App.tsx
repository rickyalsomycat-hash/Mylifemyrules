import React, { useState, useEffect, useMemo, useCallback } from 'react';
import LoginScreen from './components/LoginScreen';
import VotingScreen from './components/VotingScreen';
import VotingClosedScreen from './components/VotingClosedScreen';
import Header from './components/Header';
import AdminPanel from './components/AdminPanel';
import { Contestant } from './types';
import { INITIAL_NOMINEES } from './constants';

type AuthStatus = 'unauthenticated' | 'user' | 'admin';

const App: React.FC = () => {
  const [authStatus, setAuthStatus] = useState<AuthStatus>('unauthenticated');
  const [isVotingClosed, setIsVotingClosed] = useState<boolean>(false);
  const [contestants, setContestants] = useState<Contestant[]>([]);

  const dayOfWeek = useMemo(() => new Date().getDay(), []); // 0 = Sunday, 6 = Saturday

  // Load contestants from localStorage on initial render
  useEffect(() => {
    try {
      const savedContestants = localStorage.getItem('contestants');
      if (savedContestants) {
        setContestants(JSON.parse(savedContestants));
      } else {
        // First time load, use initial nominees
        setContestants(INITIAL_NOMINEES.map(c => ({ ...c, votes: 0 })));
      }
    } catch (error) {
      console.error("Failed to parse contestants from localStorage", error);
      setContestants(INITIAL_NOMINEES.map(c => ({ ...c, votes: 0 })));
    }
  }, []);

  // Persist contestants to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('contestants', JSON.stringify(contestants));
  }, [contestants]);

  // Handle weekly open/close logic
  useEffect(() => {
    if (dayOfWeek === 6) { // Saturday
      setIsVotingClosed(true);
    } else {
      setIsVotingClosed(false);
    }
    
    if (dayOfWeek === 0) { // Sunday
      // Reset votes, but keep the nominees
      setContestants(prev => prev.map(c => ({ ...c, votes: 0 })));
      localStorage.removeItem('lastVoteDate');
      localStorage.removeItem('userVotesToday');
    }
  }, [dayOfWeek]);

  const handleLoginSuccess = (role: 'user' | 'admin') => {
    setAuthStatus(role);
  };

  const handleAddContestant = (name: string, image: string) => {
    const newContestant: Contestant = {
      id: Date.now(), // Use timestamp for unique ID
      name,
      image,
      votes: 0,
    };
    setContestants(prev => [...prev, newContestant]);
  };

  const handleDeleteContestant = (id: number) => {
    setContestants(prev => prev.filter(c => c.id !== id));
  };

  const handleUpdateContestantVotes = (updatedContestants: Contestant[]) => {
    setContestants(updatedContestants);
  };

  const renderContent = () => {
    if (authStatus === 'unauthenticated') {
      return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
    }
    if (authStatus === 'admin') {
      return <AdminPanel 
        contestants={contestants} 
        onAddContestant={handleAddContestant}
        onDeleteContestant={handleDeleteContestant}
      />;
    }
    // User is authenticated
    if (isVotingClosed) {
      return <VotingClosedScreen results={contestants} />;
    }
    return <VotingScreen contestants={contestants} onVotesChange={handleUpdateContestantVotes} />;
  };

  return (
    <div className="bg-gradient-to-br from-brand-blue to-brand-purple min-h-screen text-white font-sans flex flex-col items-center p-4 selection:bg-brand-pink selection:text-white">
      <Header />
      <main className="w-full max-w-5xl mt-8 animate-fade-in">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;
