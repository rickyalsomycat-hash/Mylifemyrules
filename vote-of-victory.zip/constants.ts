import { Contestant } from './types';

export const CORRECT_LOGIN_CODE = "1136";
export const ADMIN_LOGIN_CODE = "925125";
export const DAILY_VOTE_LIMIT = 50;

// This is a fallback list used only if no nominees are configured in localStorage.
export const INITIAL_NOMINEES: Omit<Contestant, 'votes'>[] = [
  { id: 1, name: "Mickey", image: "https://picsum.photos/seed/mickey/200" },
  { id: 2, name: "Elsa", image: "https://picsum.photos/seed/elsa/200" },
  { id: 3, name: "Buzz", image: "https://picsum.photos/seed/buzz/200" },
  { id: 4, name: "Moana", image: "https://picsum.photos/seed/moana/200" },
  { id: 5, name: "Simba", image: "https://picsum.photos/seed/simba/200" },
];