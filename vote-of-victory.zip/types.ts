export interface Contestant {
  id: number;
  name: string;
  image: string; // Can be a URL or a base64 string
  votes: number;
  rank?: number;
  grade?: 'A' | 'B' | 'C' | 'F';
}
