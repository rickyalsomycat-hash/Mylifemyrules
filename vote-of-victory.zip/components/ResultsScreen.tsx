import React, { useMemo } from 'react';
import { Contestant } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, LabelList } from 'recharts';

interface ResultsScreenProps {
  contestants: Contestant[];
  onBack: () => void;
  isFinalResults?: boolean;
}

const GRADE_COLORS = {
  A: '#10b981', // Green
  B: '#3b82f6', // Blue
  C: '#f97316', // Orange
  F: '#ef4444', // Red
};

const getGrade = (rank: number, total: number): Contestant['grade'] => {
  if (total <= 2) {
    if (rank > total - 2) return 'F';
  }
  if (rank > total - 2) return 'F';
  const percentage = (total - rank + 1) / total;
  if (percentage >= 0.75) return 'A';
  if (percentage >= 0.4) return 'B';
  return 'C';
};

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-2 bg-black/50 backdrop-blur-sm rounded-lg border border-white/20">
          <p className="font-bold text-lg text-white">{`${payload[0].payload.name}`}</p>
          <p className="text-brand-yellow">{`Votes: ${payload[0].value}`}</p>
          <p style={{color: GRADE_COLORS[payload[0].payload.grade]}}>{`Grade: ${payload[0].payload.grade}`}</p>
        </div>
      );
    }
    return null;
  };

const CustomizedYAxisTick = (props: any) => {
  const { x, y, payload } = props;
  const { name, grade, rank, totalContestants } = payload.value;
  const isDangerZone = rank > totalContestants - 2;

  return (
    <g transform={`translate(${x},${y})`}>
      <text x={-10} y={0} dy={5} textAnchor="end" fill="#fff" className="font-bold text-sm">
        {name}
      </text>
      <text x={-10} y={0} dy={20} textAnchor="end" fill={GRADE_COLORS[grade]} className="font-bold text-xs">
        {isDangerZone && totalContestants > 2 ? `Grade ${grade} (Danger Zone)` : `Grade ${grade}`}
      </text>
    </g>
  );
};


const ResultsScreen: React.FC<ResultsScreenProps> = ({ contestants, onBack, isFinalResults = false }) => {
  const processedData = useMemo(() => {
    const sorted = [...contestants].sort((a, b) => b.votes - a.votes);
    return sorted.map((c, index) => {
      const rank = index + 1;
      const grade = getGrade(rank, sorted.length);
      return { ...c, rank, grade, totalContestants: sorted.length };
    });
  }, [contestants]);

  return (
    <div className="w-full flex flex-col items-center p-6 bg-white/10 backdrop-blur-md rounded-2xl shadow-xl border border-white/20 animate-pop-in">
      <h2 className="text-4xl font-bold mb-6 font-comic text-brand-yellow" style={{textShadow: '2px 2px 0 #000'}}>
        {isFinalResults ? "Final Weekly Results" : "Current Standings"}
      </h2>
      
      <div className="w-full h-[500px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={processedData} layout="vertical" margin={{ top: 5, right: 30, left: 100, bottom: 5 }}>
            <XAxis type="number" hide />
            <YAxis 
              dataKey="name" 
              type="category" 
              width={100}
              tickLine={false}
              axisLine={false}
              interval={0}
              tick={<CustomizedYAxisTick />}
            />
            <Tooltip content={<CustomTooltip />} cursor={{fill: 'rgba(255,255,255,0.1)'}}/>
            <Bar dataKey="votes" barSize={40} radius={[0, 10, 10, 0]}>
              <LabelList dataKey="votes" position="right" offset={10} className="font-bold fill-white" />
              {processedData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={GRADE_COLORS[entry.grade || 'C']} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {!isFinalResults && (
        <button
          onClick={onBack}
          className="mt-8 px-8 py-3 bg-gradient-to-r from-brand-pink to-orange-400 text-white font-bold text-xl rounded-full shadow-lg hover:scale-105 transform transition-transform duration-300 focus:outline-none focus:ring-4 focus:ring-brand-yellow"
        >
          Back to Voting
        </button>
      )}
    </div>
  );
};

export default ResultsScreen;
